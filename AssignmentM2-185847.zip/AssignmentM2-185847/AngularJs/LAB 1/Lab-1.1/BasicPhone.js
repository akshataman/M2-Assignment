"use strict";
exports.__esModule = true;
var Basic = /** @class */ (function () {
    function Basic() {
    }
    Basic.printType = function () {
        return "BasicPhone";
    };
    return Basic;
}());
exports.Basic = Basic;
